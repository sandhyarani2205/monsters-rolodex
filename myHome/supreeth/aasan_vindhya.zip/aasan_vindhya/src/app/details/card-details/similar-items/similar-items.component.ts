import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-similar-items',
  templateUrl: './similar-items.component.html',
  styleUrls: ['./similar-items.component.scss']
})
export class SimilarItemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
