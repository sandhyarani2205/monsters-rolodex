import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recently-visited',
  templateUrl: './recently-visited.component.html',
  styleUrls: ['./recently-visited.component.scss']
})
export class RecentlyVisitedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
