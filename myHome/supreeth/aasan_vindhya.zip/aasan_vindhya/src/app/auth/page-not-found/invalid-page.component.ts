import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalid-page',
  templateUrl: './invalid-page.component.html',
  styleUrls: ['./invalid-page.component.css']
})
export class InvalidPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
